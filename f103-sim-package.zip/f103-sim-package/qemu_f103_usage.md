# QEMU STM32F103 协同仿真使用文档

基于 QEMU 11.1.3 + 自建 `nucleo-f103rb` 机器（STM32F103 SoC + RCC + I2C1 + SHT31/ADXL345/INA219），
跑真实 FreeRTOS 固件并运行时调传感器参数。

## 前置

- QEMU 11.1.3 从源码构建（arm-softmmu），已含 `nucleo-f103rb` 机器。
- 运行时需 MSYS2 mingw64 DLL：`PATH` 加上 `C:\msys64\mingw64\bin`。
- 固件 ELF（三个工程各自已编译）。

## 运行

```bat
qemu-system-arm -machine nucleo-f103rb -kernel <firmware.elf> ^
    -serial null -serial stdio -display none
```

串口映射：USART2 接在 **serial 1**（serial 0 = null，serial 1 = stdio），所以必须
`-serial null -serial stdio`，否则看不到输出。

## 传感器运行时调参（`-global`）

属性值是固定单位（毫度 / 毫百分 / 微安 / 毫伏）：

| 器件 | 属性 | 单位 | 例 |
|---|---|---|---|
| SHT31 | `temp_mc` | 毫摄氏度 | `-global sht31.temp_mc=30000`（30.00°C） |
| SHT31 | `rh_mc` | 毫百分 | `-global sht31.rh_mc=60000`（60.0%） |
| ADXL345 | `roll_mdeg` | 毫度（有符号） | `-global adxl345.roll_mdeg=10000`（10°） |
| ADXL345 | `pitch_mdeg` | 毫度 | `-global adxl345.pitch_mdeg=-5000` |
| INA219 | `current_ua` | 微安 | `-global ina219.current_ua=1400000`（1.4A） |
| INA219 | `bus_mv` | 毫伏 | `-global ina219.bus_mv=12000`（12V） |

## 三个工程

| 工程 | ELF | 预期输出（默认参数） |
|---|---|---|
| fanctl | `3_1/dist/fanctl_nucleo_f103.elf` | `[SHT31] sample ok: T=25.00 C RH=49.9 %RH` |
| leveler | `3_2/auto_leveler/build/leveler_f103.elf` | `[boot] ADXL345 ... DEVID=0xE5`，`STATE angle=+0.00 deg` |
| monitor | `3_3/current_monitor/dist/current_monitor.elf` | `[BOOT] INA219 addr 0x40: online`，`MEAS I=0.0000A U=12.00V` |

调参验证（控制闭环）：

| 工程 | 调参 | 执行器结果 |
|---|---|---|
| fanctl | `sht31.temp_mc=30000` | TIM2 CCR1=100（风扇开） |
| leveler | `adxl345.roll_mdeg=10000` | `drive=PA0 active=1`（电机开） |
| monitor | `ina219.current_ua=1400000` | `switch=OFF`（继电器跳闸） |

## 可观测点（monitor）

用 `-monitor tcp:127.0.0.1:5556,server,nowait` 挂 monitor，然后：

```
xp /1w 0x40000034   # TIM2 CCR1（风扇/电机占空比）
xp /1w 0x4000002c   # TIM2 ARR（PWM 周期）
xp /1w 0x4001080c   # GPIOA ODR（继电器 PA0，bit0）
```

## 已知边界（本模型未实现）

- RCC 无真实 PLL/时钟树：SoC 固定 72MHz，只提供 ready 标志。
- TIM2/TIM4/GPIO 是纯寄存器存储（RAM 后端），**无波形/无定时器中断/无电气行为**；TIM4 不驱动 `HAL_GetTick`。
- 传感器参数默认值：SHT31 25.00°C/50.0%，ADXL345 水平，INA219 0A/12V。
- 非周期精确，仅验证「固件启动 + 读传感器 + 控制闭环（寄存器可观测）」。
