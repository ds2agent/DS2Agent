/*
 * STM32F103 RCC (reset and clock control)
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#include "qemu/osdep.h"
#include "qemu/log.h"
#include "hw/misc/stm32f103_rcc.h"

/* CR reset value: HSI on after reset */
#define RCC_CR_RESET  0x00000083  /* HSION=1, HSIRDY=1, HSICAL default */

static uint64_t stm32f103_rcc_read(void *opaque, hwaddr offset,
                                   unsigned size)
{
    STM32F103RccState *s = opaque;
    uint32_t v = 0;

    switch (offset) {
    case RCC_CR:
        v = s->cr;
        /* ready flags follow the ON bits */
        if (s->cr & 0x1) {
            v |= 0x2;               /* HSIRDY */
        }
        if (s->cr & R_CR_HSEON) {
            v |= R_CR_HSERDY;
        }
        if (s->cr & R_CR_PLLON) {
            v |= R_CR_PLLRDY;
        }
        break;
    case RCC_CFGR:
        v = s->cfgr;
        /* SWS (status) follows SW (source) */
        v = (v & ~0x0C) | ((v & 0x03) << 2);
        break;
    case RCC_AHBENR:
        v = s->ahbenr;
        break;
    case RCC_APB2ENR:
        v = s->apb2enr;
        break;
    case RCC_APB1ENR:
        v = s->apb1enr;
        break;
    default:
        qemu_log_mask(LOG_UNIMP, "stm32f103-rcc: read @0x%" HWADDR_PRIx "\n",
                      offset);
        break;
    }
    return v;
}

static void stm32f103_rcc_write(void *opaque, hwaddr offset,
                                uint64_t value, unsigned size)
{
    STM32F103RccState *s = opaque;

    switch (offset) {
    case RCC_CR:
        /* mask out read-only ready/status bits */
        s->cr = value & ~(0x2 | R_CR_HSERDY | R_CR_PLLRDY);
        break;
    case RCC_CFGR:
        s->cfgr = value;
        break;
    case RCC_AHBENR:
        s->ahbenr = value;
        break;
    case RCC_APB2ENR:
        s->apb2enr = value;
        break;
    case RCC_APB1ENR:
        s->apb1enr = value;
        break;
    default:
        qemu_log_mask(LOG_UNIMP, "stm32f103-rcc: write @0x%" HWADDR_PRIx
                      " = 0x%" PRIx64 "\n", offset, value);
        break;
    }
}

static const MemoryRegionOps stm32f103_rcc_ops = {
    .read = stm32f103_rcc_read,
    .write = stm32f103_rcc_write,
    .endianness = DEVICE_NATIVE_ENDIAN,
};

static void stm32f103_rcc_reset(DeviceState *dev)
{
    STM32F103RccState *s = STM32F103_RCC(dev);
    s->cr = RCC_CR_RESET;
    s->cfgr = 0;
    s->ahbenr = 0;
    s->apb2enr = 0;
    s->apb1enr = 0;
}

static void stm32f103_rcc_init(Object *obj)
{
    STM32F103RccState *s = STM32F103_RCC(obj);
    memory_region_init_io(&s->mmio, obj, &stm32f103_rcc_ops, s,
                          TYPE_STM32F103_RCC, 0x400);
    sysbus_init_mmio(SYS_BUS_DEVICE(obj), &s->mmio);
}

static void stm32f103_rcc_class_init(ObjectClass *klass, const void *data)
{
    DeviceClass *dc = DEVICE_CLASS(klass);
    device_class_set_legacy_reset(dc, stm32f103_rcc_reset);
}

static const TypeInfo stm32f103_rcc_info = {
    .name          = TYPE_STM32F103_RCC,
    .parent        = TYPE_SYS_BUS_DEVICE,
    .instance_size = sizeof(STM32F103RccState),
    .instance_init = stm32f103_rcc_init,
    .class_init    = stm32f103_rcc_class_init,
};

static void stm32f103_rcc_register_types(void)
{
    type_register_static(&stm32f103_rcc_info);
}

type_init(stm32f103_rcc_register_types)
