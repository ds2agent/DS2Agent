/*
 * STM32F103 I2C master controller + sensor slaves (SHT31/ADXL345/INA219)
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#include "qemu/osdep.h"
#include "qemu/log.h"
#include <math.h>
#include "hw/i2c/stm32f103_i2c.h"
#include "hw/core/qdev-properties.h"

/* ============================ controller ============================ */

static void stm32f103_i2c_start(STM32F103I2CState *s)
{
    /* End any previous transfer. The STM32 HAL reads the remaining bytes
     * after STOP, so the end is deferred from STOP to the next START. */
    i2c_end_transfer(s->bus);
    s->sr1 = (s->sr1 & ~(I2C_SR1_RXNE | I2C_SR1_BTF)) | I2C_SR1_SB;
    s->sr2 |= I2C_SR2_MSL | I2C_SR2_BUSY;
    s->in_transfer = false;
}

static void stm32f103_i2c_stop(STM32F103I2CState *s)
{
    /* Do not end the transfer here: the HAL reads the last bytes after
     * STOP. The end is deferred to the next START. */
    s->sr1 &= ~I2C_SR1_BTF;
    s->sr2 &= ~(I2C_SR2_MSL | I2C_SR2_BUSY);
}

static void stm32f103_i2c_dr_write(STM32F103I2CState *s, uint8_t b)
{
    if (!s->in_transfer) {
        /* address byte */
        bool is_recv = b & 1;
        int rc;

        s->addr = b >> 1;
        s->tra = !is_recv;
        s->sr1 &= ~I2C_SR1_SB;

        if (is_recv) {
            rc = i2c_start_recv(s->bus, s->addr);
        } else {
            rc = i2c_start_send(s->bus, s->addr);
        }
        s->in_transfer = (rc == 0);

        if (rc != 0) {
            s->sr1 |= I2C_SR1_AF;
            return;
        }
        if (is_recv) {
            s->sr2 &= ~I2C_SR2_TRA;
        } else {
            s->sr2 |= I2C_SR2_TRA;
        }
        s->sr1 |= I2C_SR1_ADDR;
    } else {
        /* data byte (transmit) */
        if (s->tra) {
            if (i2c_send(s->bus, b) != 0) {
                s->sr1 |= I2C_SR1_AF;
            }
            s->sr1 |= I2C_SR1_BTF | I2C_SR1_TXE;
        }
    }
}

static uint8_t stm32f103_i2c_dr_read(STM32F103I2CState *s)
{
    return i2c_recv(s->bus);
}

static uint64_t stm32f103_i2c_read(void *opaque, hwaddr offset, unsigned size)
{
    STM32F103I2CState *s = opaque;

    switch (offset) {
    case 0x00:   /* CR1 */
        return s->cr1;
    case 0x10:   /* DR */
        return stm32f103_i2c_dr_read(s);
    case 0x14:   /* SR1 */
        s->sr1_read = true;
        return s->sr1;
    case 0x18:   /* SR2 */
        if (s->sr1_read && (s->sr1 & I2C_SR1_ADDR)) {
            s->sr1 &= ~I2C_SR1_ADDR;
            if (s->tra) {
                s->sr1 |= I2C_SR1_TXE;
            } else {
                s->sr1 |= I2C_SR1_RXNE | I2C_SR1_BTF;
            }
        }
        s->sr1_read = false;
        return s->sr2;
    default:
        return 0;
    }
}

static void stm32f103_i2c_write(void *opaque, hwaddr offset,
                                uint64_t value, unsigned size)
{
    STM32F103I2CState *s = opaque;

    switch (offset) {
    case 0x00:   /* CR1 */
        if (value & I2C_CR1_START) {
            stm32f103_i2c_start(s);
        }
        if (value & I2C_CR1_STOP) {
            stm32f103_i2c_stop(s);
        }
        s->cr1 = value & ~(I2C_CR1_START | I2C_CR1_STOP);
        break;
    case 0x10:   /* DR */
        stm32f103_i2c_dr_write(s, value & 0xFF);
        break;
    default:
        break;
    }
}

static const MemoryRegionOps stm32f103_i2c_ops = {
    .read = stm32f103_i2c_read,
    .write = stm32f103_i2c_write,
    .endianness = DEVICE_NATIVE_ENDIAN,
};

static void stm32f103_i2c_reset(DeviceState *dev)
{
    STM32F103I2CState *s = STM32F103_I2C(dev);
    s->cr1 = 0;
    s->sr1 = I2C_SR1_TXE;   /* TxE set after reset */
    s->sr2 = 0;
    s->sr1_read = false;
    s->tra = false;
    s->in_transfer = false;
    s->addr = 0;
}

static void stm32f103_i2c_init(Object *obj)
{
    STM32F103I2CState *s = STM32F103_I2C(obj);
    memory_region_init_io(&s->mmio, obj, &stm32f103_i2c_ops, s,
                          TYPE_STM32F103_I2C, 0x400);
    sysbus_init_mmio(SYS_BUS_DEVICE(obj), &s->mmio);
    s->bus = i2c_init_bus(DEVICE(obj), "i2c");
}

static void stm32f103_i2c_class_init(ObjectClass *klass, const void *data)
{
    DeviceClass *dc = DEVICE_CLASS(klass);
    device_class_set_legacy_reset(dc, stm32f103_i2c_reset);
}

static const TypeInfo stm32f103_i2c_info = {
    .name          = TYPE_STM32F103_I2C,
    .parent        = TYPE_SYS_BUS_DEVICE,
    .instance_size = sizeof(STM32F103I2CState),
    .instance_init = stm32f103_i2c_init,
    .class_init    = stm32f103_i2c_class_init,
};

/* ============================ helpers ============================ */

static uint8_t sht_crc8(uint8_t init, const uint8_t *d, int len)
{
    uint8_t crc = init;
    for (int i = 0; i < len; i++) {
        crc ^= d[i];
        for (int j = 0; j < 8; j++) {
            crc = (crc & 0x80) ? ((uint8_t)(crc << 1) ^ 0x31) : (uint8_t)(crc << 1);
        }
    }
    return crc;
}

/* ============================ SHT31 (0x44) ============================ */

#define TYPE_SHT31 "sht31"
typedef struct SHT31State SHT31State;
struct SHT31State {
    I2CSlave parent_obj;
    uint8_t cmd[2];
    int cmd_len;
    bool pending;
    int recv_idx;
    uint8_t reply[6];
    uint32_t temp_mc;   /* millidegrees C */
    uint32_t rh_mc;     /* milli-percent */
};

static void sht31_compute(SHT31State *s)
{
    double t = (double)s->temp_mc / 1000.0;
    double rh = (double)s->rh_mc / 1000.0;
    uint16_t raw_t = (uint16_t)((t + 45.0) / 175.0 * 65535.0);
    uint16_t raw_rh = (uint16_t)(rh / 100.0 * 65535.0);
    uint8_t tb[2] = { raw_t >> 8, raw_t & 0xFF };
    uint8_t rb[2] = { raw_rh >> 8, raw_rh & 0xFF };
    s->reply[0] = tb[0]; s->reply[1] = tb[1]; s->reply[2] = sht_crc8(0xFF, tb, 2);
    s->reply[3] = rb[0]; s->reply[4] = rb[1]; s->reply[5] = sht_crc8(0xFF, rb, 2);
}

static int sht31_send(I2CSlave *i2c, uint8_t data)
{
    SHT31State *s = (SHT31State *)i2c;
    if (s->cmd_len < 2) {
        s->cmd[s->cmd_len++] = data;
    }
    if (s->cmd_len == 2) {
        s->pending = true;
    }
    return 0;
}

static uint8_t sht31_recv(I2CSlave *i2c)
{
    SHT31State *s = (SHT31State *)i2c;
    if (!s->pending || s->recv_idx >= 6) {
        return 0x00;
    }
    return s->reply[s->recv_idx++];
}

static int sht31_event(I2CSlave *i2c, enum i2c_event event)
{
    SHT31State *s = (SHT31State *)i2c;
    if (event == I2C_START_SEND) {
        s->cmd_len = 0;
    }
    if (event == I2C_START_RECV) {
        s->recv_idx = 0;
        if (s->pending) {
            sht31_compute(s);
        }
    }
    return 0;
}

static const Property sht31_props[] = {
    DEFINE_PROP_UINT32("temp_mc", SHT31State, temp_mc, 25000),
    DEFINE_PROP_UINT32("rh_mc", SHT31State, rh_mc, 50000),
};

static void sht31_reset(DeviceState *dev)
{
    SHT31State *s = (SHT31State *)dev;
    s->cmd_len = 0;
    s->pending = false;
    s->recv_idx = 0;
}

static void sht31_class_init(ObjectClass *klass, const void *data)
{
    DeviceClass *dc = DEVICE_CLASS(klass);
    I2CSlaveClass *sc = I2C_SLAVE_CLASS(klass);
    device_class_set_legacy_reset(dc, sht31_reset);
    device_class_set_props(dc, sht31_props);
    sc->send = sht31_send;
    sc->recv = sht31_recv;
    sc->event = sht31_event;
}

static const TypeInfo sht31_info = {
    .name          = TYPE_SHT31,
    .parent        = TYPE_I2C_SLAVE,
    .instance_size = sizeof(SHT31State),
    .class_init    = sht31_class_init,
};

/* ============================ ADXL345 (0x53) ============================ */

#define TYPE_ADXL345 "adxl345"
typedef struct ADXL345State ADXL345State;
struct ADXL345State {
    I2CSlave parent_obj;
    uint8_t reg;
    int recv_idx;
    uint8_t reply[6];
    int32_t roll_mdeg;   /* millidegrees */
    int32_t pitch_mdeg;  /* millidegrees */
};

static void adxl345_compute(ADXL345State *s)
{
    double roll = (double)s->roll_mdeg / 1000.0 * 3.141592653589793 / 180.0;
    double pitch = (double)s->pitch_mdeg / 1000.0 * 3.141592653589793 / 180.0;
    double ax = sin(roll);
    double ay = sin(pitch);
    double az = cos(roll) * cos(pitch);
    int16_t x = (int16_t)(ax * 256.0);
    int16_t y = (int16_t)(ay * 256.0);
    int16_t z = (int16_t)(az * 256.0);
    s->reply[0] = x & 0xFF; s->reply[1] = (x >> 8) & 0xFF;
    s->reply[2] = y & 0xFF; s->reply[3] = (y >> 8) & 0xFF;
    s->reply[4] = z & 0xFF; s->reply[5] = (z >> 8) & 0xFF;
}

static int adxl345_send(I2CSlave *i2c, uint8_t data)
{
    ADXL345State *s = (ADXL345State *)i2c;
    s->reg = data;
    return 0;
}

static uint8_t adxl345_recv(I2CSlave *i2c)
{
    ADXL345State *s = (ADXL345State *)i2c;
    if (s->reg == 0x00) {
        return 0xE5;   /* DEVID */
    }
    if (s->reg == 0x32) {
        if (s->recv_idx >= 6) {
            return 0x00;
        }
        return s->reply[s->recv_idx++];
    }
    return 0x00;
}

static int adxl345_event(I2CSlave *i2c, enum i2c_event event)
{
    ADXL345State *s = (ADXL345State *)i2c;
    if (event == I2C_START_SEND) {
        s->reg = 0;
    }
    if (event == I2C_START_RECV) {
        s->recv_idx = 0;
        if (s->reg == 0x32) {
            adxl345_compute(s);
        }
    }
    return 0;
}

static const Property adxl345_props[] = {
    DEFINE_PROP_INT32("roll_mdeg", ADXL345State, roll_mdeg, 0),
    DEFINE_PROP_INT32("pitch_mdeg", ADXL345State, pitch_mdeg, 0),
};

static void adxl345_reset(DeviceState *dev)
{
    ADXL345State *s = (ADXL345State *)dev;
    s->reg = 0;
    s->recv_idx = 0;
}

static void adxl345_class_init(ObjectClass *klass, const void *data)
{
    DeviceClass *dc = DEVICE_CLASS(klass);
    I2CSlaveClass *sc = I2C_SLAVE_CLASS(klass);
    device_class_set_legacy_reset(dc, adxl345_reset);
    device_class_set_props(dc, adxl345_props);
    sc->send = adxl345_send;
    sc->recv = adxl345_recv;
    sc->event = adxl345_event;
}

static const TypeInfo adxl345_info = {
    .name          = TYPE_ADXL345,
    .parent        = TYPE_I2C_SLAVE,
    .instance_size = sizeof(ADXL345State),
    .class_init    = adxl345_class_init,
};

/* ============================ INA219 (0x40) ============================ */

#define TYPE_INA219 "ina219"
typedef struct INA219State INA219State;
struct INA219State {
    I2CSlave parent_obj;
    uint8_t reg;
    int recv_idx;
    uint8_t reply[2];
    uint32_t current_ua;   /* microamps */
    uint32_t bus_mv;       /* millivolts */
};

static void ina219_compute(INA219State *s)
{
    uint16_t v = 0;
    switch (s->reg) {
    case 0x00:  /* CONFIG */
        v = 0x399F;
        break;
    case 0x05:  /* CALIBRATION */
        v = 4096;
        break;
    case 0x04:  /* CURRENT (100 uA/LSB) */
        v = (uint16_t)(s->current_ua / 100);
        break;
    case 0x02:  /* BUS voltage (4 mV/LSB) */
        v = (uint16_t)((s->bus_mv / 4) << 3);
        break;
    default:
        v = 0;
        break;
    }
    s->reply[0] = v >> 8;
    s->reply[1] = v & 0xFF;
}

static int ina219_send(I2CSlave *i2c, uint8_t data)
{
    INA219State *s = (INA219State *)i2c;
    s->reg = data;
    return 0;
}

static uint8_t ina219_recv(I2CSlave *i2c)
{
    INA219State *s = (INA219State *)i2c;
    if (s->recv_idx >= 2) {
        return 0x00;
    }
    return s->reply[s->recv_idx++];
}

static int ina219_event(I2CSlave *i2c, enum i2c_event event)
{
    INA219State *s = (INA219State *)i2c;
    if (event == I2C_START_SEND) {
        s->reg = 0;
    }
    if (event == I2C_START_RECV) {
        s->recv_idx = 0;
        ina219_compute(s);
    }
    return 0;
}

static const Property ina219_props[] = {
    DEFINE_PROP_UINT32("current_ua", INA219State, current_ua, 0),
    DEFINE_PROP_UINT32("bus_mv", INA219State, bus_mv, 12000),
};

static void ina219_reset(DeviceState *dev)
{
    INA219State *s = (INA219State *)dev;
    s->reg = 0;
    s->recv_idx = 0;
}

static void ina219_class_init(ObjectClass *klass, const void *data)
{
    DeviceClass *dc = DEVICE_CLASS(klass);
    I2CSlaveClass *sc = I2C_SLAVE_CLASS(klass);
    device_class_set_legacy_reset(dc, ina219_reset);
    device_class_set_props(dc, ina219_props);
    sc->send = ina219_send;
    sc->recv = ina219_recv;
    sc->event = ina219_event;
}

static const TypeInfo ina219_info = {
    .name          = TYPE_INA219,
    .parent        = TYPE_I2C_SLAVE,
    .instance_size = sizeof(INA219State),
    .class_init    = ina219_class_init,
};

/* ============================ registration ============================ */

static void stm32f103_i2c_register_types(void)
{
    type_register_static(&stm32f103_i2c_info);
    type_register_static(&sht31_info);
    type_register_static(&adxl345_info);
    type_register_static(&ina219_info);
}

type_init(stm32f103_i2c_register_types)
