/*
 * NUCLEO-F103RB machine (STM32F103RB, Cortex-M3)
 *
 * Derived from stm32vldiscovery by the ds2agent project.
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#include "qemu/osdep.h"
#include "qapi/error.h"
#include "hw/arm/stm32f103_soc.h"
#include "hw/arm/boot.h"
#include "hw/core/qdev-clock.h"
#include "hw/arm/machines-qom.h"

/* Main SYSCLK frequency in Hz (72MHz: HSE 8MHz x9) */
#define SYSCLK_FRQ 72000000ULL

static void nucleo_f103rb_init(MachineState *machine)
{
    DeviceState *dev;
    Clock *sysclk;

    sysclk = clock_new(OBJECT(machine), "SYSCLK");
    clock_set_hz(sysclk, SYSCLK_FRQ);

    dev = qdev_new(TYPE_STM32F103_SOC);
    object_property_add_child(OBJECT(machine), "soc", OBJECT(dev));
    qdev_connect_clock_in(dev, "sysclk", sysclk);
    sysbus_realize_and_unref(SYS_BUS_DEVICE(dev), &error_fatal);

    armv7m_load_kernel(STM32F103_SOC(dev)->armv7m.cpu,
                       machine->kernel_filename,
                       0, FLASH_SIZE);
}

static void nucleo_f103rb_machine_init(MachineClass *mc)
{
    static const char * const valid_cpu_types[] = {
        ARM_CPU_TYPE_NAME("cortex-m3"),
        NULL
    };

    mc->desc = "NUCLEO-F103RB (STM32F103, Cortex-M3)";
    mc->init = nucleo_f103rb_init;
    mc->valid_cpu_types = valid_cpu_types;
}

DEFINE_MACHINE_ARM("nucleo-f103rb", nucleo_f103rb_machine_init)
