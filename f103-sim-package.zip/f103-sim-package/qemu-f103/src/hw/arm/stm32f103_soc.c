/*
 * STM32F103 SoC (NUCLEO-F103RB)
 *
 * Derived from stm32f100_soc by the ds2agent project.
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#include "qemu/osdep.h"
#include "qapi/error.h"
#include "qemu/module.h"
#include "hw/arm/boot.h"
#include "system/address-spaces.h"
#include "hw/arm/stm32f103_soc.h"
#include "hw/core/qdev-properties.h"
#include "hw/core/qdev-clock.h"
#include "hw/misc/unimp.h"
#include "hw/misc/stm32f103_rcc.h"
#include "hw/i2c/stm32f103_i2c.h"
#include "system/system.h"

static const uint32_t usart_addr[STM_NUM_USARTS] = { 0x40013800, 0x40004400,
    0x40004800 };
static const int usart_irq[STM_NUM_USARTS] = {37, 38, 39};

static void stm32f103_soc_initfn(Object *obj)
{
    STM32F103State *s = STM32F103_SOC(obj);
    int i;

    object_initialize_child(obj, "armv7m", &s->armv7m, TYPE_ARMV7M);
    object_initialize_child(obj, "rcc", &s->rcc, TYPE_STM32F103_RCC);
    object_initialize_child(obj, "i2c[*]", &s->i2c[0], TYPE_STM32F103_I2C);

    for (i = 0; i < STM_NUM_USARTS; i++) {
        object_initialize_child(obj, "usart[*]", &s->usart[i],
                                TYPE_STM32F2XX_USART);
    }

    s->sysclk = qdev_init_clock_in(DEVICE(s), "sysclk", NULL, NULL, 0);
    s->refclk = qdev_init_clock_in(DEVICE(s), "refclk", NULL, NULL, 0);
}

static void stm32f103_soc_realize(DeviceState *dev_soc, Error **errp)
{
    STM32F103State *s = STM32F103_SOC(dev_soc);
    DeviceState *dev, *armv7m;
    SysBusDevice *busdev;
    int i;

    MemoryRegion *system_memory = get_system_memory();

    if (clock_has_source(s->refclk)) {
        error_setg(errp, "refclk clock must not be wired up by the board code");
        return;
    }
    if (!clock_has_source(s->sysclk)) {
        error_setg(errp, "sysclk clock must be wired up by the board code");
        return;
    }

    /* refclk runs at HCLK / 8 */
    clock_set_mul_div(s->refclk, 8, 1);
    clock_set_source(s->refclk, s->sysclk);

    /* Flash at 0x08000000, aliased to boot memory at 0x0 */
    memory_region_init_rom(&s->flash, OBJECT(dev_soc), "STM32F103.flash",
                           FLASH_SIZE, &error_fatal);
    memory_region_init_alias(&s->flash_alias, OBJECT(dev_soc),
                             "STM32F103.flash.alias", &s->flash, 0, FLASH_SIZE);
    memory_region_add_subregion(system_memory, FLASH_BASE_ADDRESS, &s->flash);
    memory_region_add_subregion(system_memory, 0, &s->flash_alias);

    /* SRAM */
    memory_region_init_ram(&s->sram, NULL, "STM32F103.sram", SRAM_SIZE,
                           &error_fatal);
    memory_region_add_subregion(system_memory, SRAM_BASE_ADDRESS, &s->sram);

    /* ARMv7m (Cortex-M3) */
    armv7m = DEVICE(&s->armv7m);
    qdev_prop_set_uint32(armv7m, "num-irq", 61);
    qdev_prop_set_uint8(armv7m, "num-prio-bits", 4);
    qdev_prop_set_string(armv7m, "cpu-type", ARM_CPU_TYPE_NAME("cortex-m3"));
    qdev_prop_set_bit(armv7m, "enable-bitband", true);
    qdev_connect_clock_in(armv7m, "cpuclk", s->sysclk);
    qdev_connect_clock_in(armv7m, "refclk", s->refclk);
    object_property_set_link(OBJECT(&s->armv7m), "memory",
                             OBJECT(get_system_memory()), &error_abort);
    if (!sysbus_realize(SYS_BUS_DEVICE(&s->armv7m), errp)) {
        return;
    }

    /* USART controllers */
    for (i = 0; i < STM_NUM_USARTS; i++) {
        dev = DEVICE(&(s->usart[i]));
        qdev_prop_set_chr(dev, "chardev", serial_hd(i));
        if (!sysbus_realize(SYS_BUS_DEVICE(&s->usart[i]), errp)) {
            return;
        }
        busdev = SYS_BUS_DEVICE(dev);
        sysbus_mmio_map(busdev, 0, usart_addr[i]);
        sysbus_connect_irq(busdev, 0, qdev_get_gpio_in(armv7m, usart_irq[i]));
    }

    /* Everything else is stubbed; RCC/I2C/GPIO/TIM get real models next. */
    /* TIM2/TIM4: register storage (PWM duty observable, no waveform) */
    memory_region_init_ram(&s->tim2, NULL, "STM32F103.tim2", 0x400, &error_fatal);
    memory_region_add_subregion(system_memory, 0x40000000, &s->tim2);
    create_unimplemented_device("timer[3]",  0x40000400, 0x400);
    memory_region_init_ram(&s->tim4, NULL, "STM32F103.tim4", 0x400, &error_fatal);
    memory_region_add_subregion(system_memory, 0x40000800, &s->tim4);
    create_unimplemented_device("timer[6]",  0x40001000, 0x400);
    create_unimplemented_device("timer[7]",  0x40001400, 0x400);
    create_unimplemented_device("RTC",       0x40002800, 0x400);
    create_unimplemented_device("WWDG",      0x40002C00, 0x400);
    create_unimplemented_device("IWDG",      0x40003000, 0x400);
    /* I2C1 + sensor slaves */
    if (!sysbus_realize(SYS_BUS_DEVICE(&s->i2c[0]), errp)) {
        return;
    }
    sysbus_mmio_map(SYS_BUS_DEVICE(&s->i2c[0]), 0, 0x40005400);
    i2c_slave_create_simple(s->i2c[0].bus, "sht31", 0x44);
    i2c_slave_create_simple(s->i2c[0].bus, "adxl345", 0x53);
    i2c_slave_create_simple(s->i2c[0].bus, "ina219", 0x40);
    create_unimplemented_device("I2C2",      0x40005800, 0x400);
    create_unimplemented_device("BKP",       0x40006C00, 0x400);
    create_unimplemented_device("PWR",       0x40007000, 0x400);
    create_unimplemented_device("DAC",       0x40007400, 0x400);
    create_unimplemented_device("CEC",       0x40007800, 0x400);
    create_unimplemented_device("AFIO",      0x40010000, 0x400);
    create_unimplemented_device("EXTI",      0x40010400, 0x400);
    /* GPIOA/GPIOB: register storage (relay/LED/pin state observable) */
    memory_region_init_ram(&s->gpioa, NULL, "STM32F103.gpioa", 0x400, &error_fatal);
    memory_region_add_subregion(system_memory, 0x40010800, &s->gpioa);
    memory_region_init_ram(&s->gpiob, NULL, "STM32F103.gpiob", 0x400, &error_fatal);
    memory_region_add_subregion(system_memory, 0x40010C00, &s->gpiob);
    create_unimplemented_device("GPIOC",     0x40011000, 0x400);
    create_unimplemented_device("GPIOD",     0x40011400, 0x400);
    create_unimplemented_device("GPIOE",     0x40011800, 0x400);
    create_unimplemented_device("ADC1",      0x40012400, 0x400);
    create_unimplemented_device("timer[1]",  0x40012C00, 0x400);
    create_unimplemented_device("timer[15]", 0x40014000, 0x400);
    create_unimplemented_device("timer[16]", 0x40014400, 0x400);
    create_unimplemented_device("timer[17]", 0x40014800, 0x400);
    create_unimplemented_device("DMA",       0x40020000, 0x400);
    /* RCC */
    if (!sysbus_realize(SYS_BUS_DEVICE(&s->rcc), errp)) {
        return;
    }
    sysbus_mmio_map(SYS_BUS_DEVICE(&s->rcc), 0, 0x40021000);
    /* FLASH interface (ACR etc.): store writes so read-back checks pass */
    memory_region_init_ram(&s->flash_if, NULL, "STM32F103.flash_if", 0x400,
                           &error_fatal);
    memory_region_add_subregion(system_memory, 0x40022000, &s->flash_if);
    create_unimplemented_device("CRC",       0x40023000, 0x400);
}

static void stm32f103_soc_class_init(ObjectClass *klass, const void *data)
{
    DeviceClass *dc = DEVICE_CLASS(klass);

    dc->realize = stm32f103_soc_realize;
}

static const TypeInfo stm32f103_soc_info = {
    .name          = TYPE_STM32F103_SOC,
    .parent        = TYPE_SYS_BUS_DEVICE,
    .instance_size = sizeof(STM32F103State),
    .instance_init = stm32f103_soc_initfn,
    .class_init    = stm32f103_soc_class_init,
};

static void stm32f103_soc_types(void)
{
    type_register_static(&stm32f103_soc_info);
}

type_init(stm32f103_soc_types)
