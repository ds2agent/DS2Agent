/*
 * STM32F103 I2C master controller + sensor slaves (SHT31/ADXL345/INA219)
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */
#ifndef HW_I2C_STM32F103_I2C_H
#define HW_I2C_STM32F103_I2C_H

#include "hw/core/sysbus.h"
#include "hw/i2c/i2c.h"
#include "qom/object.h"

#define TYPE_STM32F103_I2C "stm32f103-i2c"
OBJECT_DECLARE_SIMPLE_TYPE(STM32F103I2CState, STM32F103_I2C)

/* SR1 bits */
#define I2C_SR1_SB    0x0001
#define I2C_SR1_ADDR  0x0002
#define I2C_SR1_BTF   0x0004
#define I2C_SR1_RXNE  0x0040
#define I2C_SR1_TXE   0x0080
#define I2C_SR1_AF    0x0400

/* SR2 bits */
#define I2C_SR2_MSL   0x0001
#define I2C_SR2_BUSY  0x0002
#define I2C_SR2_TRA   0x0004

/* CR1 bits */
#define I2C_CR1_PE    0x0001
#define I2C_CR1_START 0x0100
#define I2C_CR1_STOP  0x0200

struct STM32F103I2CState {
    SysBusDevice parent_obj;

    MemoryRegion mmio;
    I2CBus *bus;

    uint16_t cr1;
    uint16_t sr1;
    uint16_t sr2;

    bool sr1_read;
    bool tra;
    bool in_transfer;
    uint8_t addr;
};

#endif
