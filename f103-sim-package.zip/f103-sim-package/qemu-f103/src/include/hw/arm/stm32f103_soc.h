/*
 * STM32F103 SoC (NUCLEO-F103RB)
 *
 * Derived from stm32f100_soc by the ds2agent project.
 * SPDX-License-Identifier: GPL-2.0-or-later
 */
#ifndef HW_ARM_STM32F103_SOC_H
#define HW_ARM_STM32F103_SOC_H

#include "hw/char/stm32f2xx_usart.h"
#include "hw/arm/armv7m.h"
#include "hw/misc/stm32f103_rcc.h"
#include "hw/i2c/stm32f103_i2c.h"
#include "qom/object.h"
#include "hw/core/clock.h"

#define TYPE_STM32F103_SOC "stm32f103-soc"
OBJECT_DECLARE_SIMPLE_TYPE(STM32F103State, STM32F103_SOC)

#define STM_NUM_USARTS 3

#define FLASH_BASE_ADDRESS 0x08000000
#define FLASH_SIZE (128 * 1024)
#define SRAM_BASE_ADDRESS 0x20000000
#define SRAM_SIZE (20 * 1024)

struct STM32F103State {
    SysBusDevice parent_obj;

    ARMv7MState armv7m;

    STM32F2XXUsartState usart[STM_NUM_USARTS];

    STM32F103RccState rcc;
    STM32F103I2CState i2c[1];

    MemoryRegion sram;
    MemoryRegion flash;
    MemoryRegion flash_alias;
    MemoryRegion flash_if;
    MemoryRegion tim2;
    MemoryRegion tim4;
    MemoryRegion gpioa;
    MemoryRegion gpiob;

    Clock *sysclk;
    Clock *refclk;
};

#endif
