/*
 * STM32F103 RCC (reset and clock control)
 *
 * Minimal model: clock-enable/ready flags follow their ON bits so the
 * firmware's SystemInit polling loop terminates. PLL/SYSCLK switching is
 * not modeled (the SoC already runs at 72 MHz).
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */
#ifndef HW_MISC_STM32F103_RCC_H
#define HW_MISC_STM32F103_RCC_H

#include "hw/core/sysbus.h"
#include "qom/object.h"

#define TYPE_STM32F103_RCC "stm32f103-rcc"
OBJECT_DECLARE_SIMPLE_TYPE(STM32F103RccState, STM32F103_RCC)

#define RCC_CR         0x00
#define RCC_CFGR       0x04
#define RCC_AHBENR     0x14
#define RCC_APB2ENR    0x18
#define RCC_APB1ENR    0x1C

#define R_CR_HSEON     (1u << 16)
#define R_CR_HSERDY    (1u << 17)
#define R_CR_PLLON     (1u << 24)
#define R_CR_PLLRDY    (1u << 25)

struct STM32F103RccState {
    SysBusDevice parent_obj;

    MemoryRegion mmio;

    uint32_t cr;
    uint32_t cfgr;
    uint32_t ahbenr;
    uint32_t apb2enr;
    uint32_t apb1enr;
};

#endif
