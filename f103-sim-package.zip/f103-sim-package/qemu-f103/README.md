# QEMU STM32F103 板子集成

## 文件

- `src/` — 7 个新文件（machine / SoC / RCC / I2C），路径相对 QEMU 源码树根。
- `qemu-f103.patch` — 对 `hw/{arm,i2c,misc}/meson.build`、`hw/{arm,i2c,misc}/Kconfig`、
  `scripts/symlink-install-tree.py` 的修改。

## 集成到 QEMU 11.1.3

1. 把 `src/` 下的文件复制到 QEMU 源码树对应路径（`hw/...`、`include/hw/...`）。
2. 应用 patch：`git apply qemu-f103.patch`（或在 QEMU 树里 `git am`）。
3. 重新 configure + build：

```bat
./configure --target-list=arm-softmmu --disable-werror
ninja -C build
```

注：`symlink-install-tree.py` 的 patch 是 Windows 无「开发者模式」时的回退（symlink 失败改为复制），
非 Windows 或已开开发者模式可忽略该 hunk。

## 运行

见 `../qemu_f103_usage.md`。
