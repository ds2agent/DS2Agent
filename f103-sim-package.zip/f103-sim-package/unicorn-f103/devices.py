"""Device models for the F103 co-simulator.

Each model is a ``Device`` subclass attached to the I2C bus; its ``params`` are
runtime-adjustable through the emulator CLI (``set``/``get``/``list``). This is
the generated "behavior model" layer — the MCU emulator and bus live in
``f103_emu.py`` and only depend on the ``Device`` interface.
"""
import math


def _crc8(data, poly=0x31, init=0x00):
    crc = init
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = ((crc << 1) ^ poly) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc


class Device:
    """Base device model attached to the I2C bus."""
    addr7 = 0x00
    name = "device"

    def __init__(self):
        self.params = {}

    def set_param(self, key, value):
        self.params[key] = value

    def get_params(self):
        return dict(self.params)

    def on_write(self, data: bytes):
        pass

    def on_read(self) -> list:
        """Return the byte list for the current read transaction (stateful)."""
        return [0]


class SHT31(Device):
    """SHT31 humidity/temperature sensor. Params: temp_c, rh_pct."""
    addr7 = 0x44
    name = "sht31"

    def __init__(self):
        super().__init__()
        self.params = {"temp_c": 25.0, "rh_pct": 50.0}
        self._pending = False

    def on_write(self, data):
        if len(data) == 2:                      # 16-bit measure command
            self._pending = True

    def on_read(self):
        if not self._pending:
            return [0] * 6
        self._pending = False
        t = min(max(self.params["temp_c"], -45.0), 130.0)
        rh = min(max(self.params["rh_pct"], 0.0), 100.0)
        raw_t = int((t + 45.0) / 175.0 * 65535.0) & 0xFFFF
        raw_rh = int(rh / 100.0 * 65535.0) & 0xFFFF
        t_hi, t_lo = (raw_t >> 8) & 0xFF, raw_t & 0xFF
        rh_hi, rh_lo = (raw_rh >> 8) & 0xFF, raw_rh & 0xFF
        return [t_hi, t_lo, _crc8([t_hi, t_lo], poly=0x31, init=0xFF),
                rh_hi, rh_lo, _crc8([rh_hi, rh_lo], poly=0x31, init=0xFF)]


class HTU21D(Device):
    """HTU21D humidity/temperature sensor. Params: temp_c, rh_pct."""
    addr7 = 0x40
    name = "htu21d"

    def __init__(self):
        super().__init__()
        self.params = {"temp_c": 25.0, "rh_pct": 50.0}
        self._cmd = 0x00

    def on_write(self, data):
        if data:
            self._cmd = data[0]

    def on_read(self):
        t = min(max(self.params["temp_c"], -40.0), 125.0)
        rh = min(max(self.params["rh_pct"], 0.0), 100.0)
        if self._cmd == 0xF3:                      # temperature
            raw = int((t + 46.85) / 175.72 * 65536.0) & 0xFFFC
        else:                                       # humidity (0xF5)
            raw = int((rh + 6.0) / 125.0 * 65536.0) & 0xFFFC
        hi, lo = (raw >> 8) & 0xFF, raw & 0xFF
        return [hi, lo, _crc8([hi, lo], poly=0x31, init=0x00)]


class ADXL345(Device):
    """ADXL345 3-axis accelerometer. Params: roll_deg, pitch_deg."""
    addr7 = 0x53
    name = "adxl345"

    def __init__(self):
        super().__init__()
        self.params = {"roll_deg": 0.0, "pitch_deg": 0.0}
        self._reg = 0x00

    def on_write(self, data):
        if data:
            self._reg = data[0]

    def on_read(self):
        if self._reg == 0x00:                      # DEVID
            return [0xE5]
        if self._reg == 0x32:                      # DATAX0..DATAZ1 (6 bytes LE)
            roll = math.radians(self.params["roll_deg"])
            pitch = math.radians(self.params["pitch_deg"])
            ax = math.sin(roll)
            ay = math.sin(pitch)
            az = math.cos(roll) * math.cos(pitch)
            x = int(ax * 256)                      # 1 g = 256 counts
            y = int(ay * 256)
            z = int(az * 256)
            return [x & 0xFF, (x >> 8) & 0xFF,
                    y & 0xFF, (y >> 8) & 0xFF,
                    z & 0xFF, (z >> 8) & 0xFF]
        return [0] * 6


class INA219(Device):
    """INA219 current/power monitor. Params: current_a, bus_v."""
    addr7 = 0x40
    name = "ina219"

    def __init__(self):
        super().__init__()
        self.params = {"current_a": 0.0, "bus_v": 12.0}
        self._reg = 0x00
        self._config = 0x399F
        self._cal = 4096

    def on_write(self, data):
        if not data:
            return
        self._reg = data[0]
        if len(data) >= 3:
            val = (data[1] << 8) | data[2]
            if self._reg == 0x00:
                self._config = val
            elif self._reg == 0x05:
                self._cal = val

    def on_read(self):
        if self._reg == 0x00:                      # CONFIG
            v = self._config
        elif self._reg == 0x05:                    # CALIBRATION
            v = self._cal
        elif self._reg == 0x04:                    # CURRENT (100 uA/LSB)
            v = int(self.params["current_a"] * 10000.0) & 0xFFFF
        elif self._reg == 0x02:                    # BUS voltage (4 mV/LSB, bits 15..3)
            v = ((int(self.params["bus_v"] * 1000.0) // 4) << 3) & 0xFFFF
        else:
            v = 0
        return [(v >> 8) & 0xFF, v & 0xFF]


def _pn532_frame(payload):
    """Wrap a PN532->host payload into a full frame."""
    tf = 0xD5
    body = bytes([tf]) + bytes(payload)
    length = len(body)
    lcs = (~length + 1) & 0xFF
    dcs = (~(sum(body) & 0xFF) + 1) & 0xFF
    return bytes([0x00, 0x00, 0xFF, length, lcs]) + body + bytes([dcs, 0x00])


class PN532(Device):
    """PN532 NFC transceiver. Params: tag_uid (bytes), tag_present (bool),
    ic, ver, rev, support."""
    addr7 = 0x48
    name = "pn532"

    def __init__(self):
        super().__init__()
        self.params = {
            "tag_uid": bytes([0x04, 0x12, 0x34, 0x56, 0x78]),
            "tag_present": True,
            "ic": 0x00, "ver": 0x01, "rev": 0x06, "support": 0x07,
        }
        self._state = "idle"
        self._response = b""

    def set_param(self, key, value):
        if key == "tag_uid" and isinstance(value, str):
            value = bytes(int(x, 16) for x in value.split())
        self.params[key] = value

    def on_write(self, data):
        # parse frame: 00 00 FF LEN LCS TFI D4 CMD.. DCS 00
        if len(data) >= 7 and data[0] == 0x00 and data[1] == 0x00 and data[2] == 0xFF:
            cmd = data[6]
            if cmd == 0x02:                 # GetFirmwareVersion
                p = self.params
                self._response = _pn532_frame([0x03, p["ic"], p["ver"], p["rev"], p["support"]])
            elif cmd == 0x14:               # SAMConfiguration
                self._response = _pn532_frame([0x15])
            elif cmd == 0x4A:               # InListPassiveTarget
                if self.params["tag_present"]:
                    uid = bytes(self.params["tag_uid"])
                    pl = [0x4B, 0x01, 0x01, 0x04, 0x00, 0x08, len(uid)] + list(uid)
                    self._response = _pn532_frame(pl)
                else:
                    self._response = _pn532_frame([0x4B, 0x00])   # no target
            else:
                self._response = b""
            self._state = "ack_ready"
        else:
            self._state = "idle"

    def on_read(self):
        if self._state == "ack_ready":
            self._state = "ack"
            return [0x01]
        if self._state == "ack":
            self._state = "resp_ready"
            return [0x01, 0x00, 0x00, 0xFF, 0x00, 0xFF, 0x00]
        if self._state == "resp_ready":
            self._state = "resp"
            return [0x01]
        if self._state == "resp":
            self._state = "idle"
            return [0x01] + list(self._response)
        return [0x00]
