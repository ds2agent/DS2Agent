"""STM32F103 (Cortex-M3) instruction-level emulator over Unicorn.

Co-simulates the F103 MCU against device models (I2C) whose parameters can be
adjusted at runtime through a CLI thread, e.g.:

    set sht31 temp 25.5      # change simulated ambient temperature
    set sht31 rh 60.0
    get sht31
    list

Requires: ``pip install unicorn``.
"""
from __future__ import annotations

import struct
import sys
import threading
from unicorn import *
from unicorn.arm_const import *

from devices import ADXL345, Device, HTU21D, INA219, PN532, SHT31

# ---- memory map ----
FLASH = 0x08000000
FLASH_SZ = 128 * 1024
SRAM = 0x20000000
SRAM_SZ = 20 * 1024
PERIPH = 0x40000000
PERIPH_SZ = 0x00030000
SYSTEM = 0xE000E000
SYSTEM_SZ = 0x1000

USART2 = 0x40004400
I2C1 = 0x40005400
RCC = 0x40021000
GPIOA = 0x40010800
GPIOB = 0x40010C00
AFIO = 0x40010000
FLASH_IF = 0x40022000
SYSTICK = 0xE000E010
SCB = 0xE000ED00
NVIC = 0xE000E100


# ============================== I2C peripheral ==============================

class I2C1Periph:
    """STM32F1 I2C master peripheral state machine (polling mode)."""
    def __init__(self, bus):
        self.bus = bus
        self.cr1 = 0
        self.sr1 = 0x80          # TxE set after reset
        self.sr2 = 0x00
        self.state = "idle"
        self.tra = False
        self.tx = bytearray()
        self.rx = []
        self.rx_idx = 0
        self.addr_w = 0
        self.sr1_read = False

    def read(self, off):
        if off == 0x00:            # CR1
            return self.cr1
        if off == 0x14:            # SR1
            self.sr1_read = True
            return self.sr1
        if off == 0x18:            # SR2 (reading SR1 then SR2 clears ADDR)
            v = self.sr2
            if self.sr1_read and (self.sr1 & 0x02):
                self.sr1 &= ~0x02
                if self.tra:
                    self.sr1 |= 0x80            # TxE
                elif self.rx_idx < len(self.rx):
                    self.sr1 |= (0x40 | 0x04)   # RxNE + BTF
            self.sr1_read = False
            return v
        if off == 0x10:            # DR read (receive byte)
            b = self.rx[self.rx_idx] if self.rx_idx < len(self.rx) else 0
            if self.rx_idx < len(self.rx):
                self.rx_idx += 1
            return b
        return 0

    def write(self, off, value):
        if off == 0x00:            # CR1
            v = value & 0xFFFF
            if v & 0x100:
                self._start()
            if v & 0x200:
                self._stop()
            # START/STOP are self-clearing in hardware; don't retain them.
            self.cr1 = v & ~(0x100 | 0x200)
            return
        if off == 0x10:            # DR write
            self._dr_write(value & 0xFF)
            return
        # CR2/OAR1/OAR2/CCR/TRISE: config, store nothing

    def _start(self):
        # A repeated START follows a register-address write in an I2C
        # "Mem_Read" transaction; the address must reach the device model
        # before the read half begins (there is no STOP in between).
        if self.state == "tx" and self.tra and self.tx:
            self.bus.write(self.addr_w, bytes(self.tx))
            self.tx = bytearray()
        self.state = "start"
        self.sr1 = (self.sr1 & ~(0x40 | 0x04)) | 0x01   # clear RxNE/BTF, set SB
        self.sr2 |= 0x03           # MSL | BUSY

    def _dr_write(self, b):
        if self.state == "start":
            is_read = bool(b & 1)
            self.addr_w = (b >> 1) & 0x7F
            self.tra = not is_read
            self.sr1 &= ~0x01       # clear SB
            if not self.bus.present(self.addr_w):
                self.sr1 |= 0x0400  # AF (NACK)
                self.state = "idle"
                return
            if is_read:
                self.rx = self.bus.read(self.addr_w)
                self.rx_idx = 0
                self.sr2 &= ~0x04   # TRA=0
                self.state = "rx"
            else:
                self.tx = bytearray()
                self.sr2 |= 0x04    # TRA=1
                self.state = "tx"
            self.sr1 |= 0x02        # ADDR
            return
        if self.state == "tx":
            self.tx.append(b)
            self.sr1 |= 0x04        # BTF
            self.sr1 |= 0x80        # TxE
            return

    def _stop(self):
        if self.tra and self.tx:
            self.bus.write(self.addr_w, bytes(self.tx))
        self.state = "idle"
        self.sr1 &= ~0x04           # clear BTF
        self.sr2 &= ~0x03           # clear MSL | BUSY
        self.tx = bytearray()


class I2CBus:
    def __init__(self):
        self.devices = {}

    def attach(self, dev):
        self.devices[dev.addr7] = dev

    def present(self, addr7):
        return addr7 in self.devices

    def write(self, addr7, data):
        dev = self.devices.get(addr7)
        if dev:
            dev.on_write(data)

    def read(self, addr7):
        dev = self.devices.get(addr7)
        return dev.on_read() if dev else [0]


# ============================== emulator ==============================

class F103:
    def __init__(self, elf_path, devices=()):
        self.elf = elf_path
        self.uc = Uc(UC_ARCH_ARM, UC_MODE_THUMB | UC_MODE_MCLASS)
        self.bus = I2CBus()
        for d in devices:
            self.bus.attach(d)
        self.i2c1 = I2C1Periph(self.bus)
        self.mmio = {}
        self.uart_tx = bytearray()
        self.uart_sr = 0xC0
        self.systick = {"ctrl": 0, "load": 0, "val": 0, "pending": False}
        self.vector = []
        self.devices = {d.name: d for d in devices}
        self._running = False
        self._exc_depth = 0
        self.pendsv_pending = False
        self._load()
        self._map()
        self._hooks()
        self.reset()

    def _load(self):
        raw = open(self.elf, "rb").read()
        e_phoff = struct.unpack_from("<I", raw, 28)[0]
        e_phentsize, e_phnum = struct.unpack_from("<HH", raw, 42)
        segs = []
        for i in range(e_phnum):
            off = e_phoff + i * e_phentsize
            p_type, p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, p_flags, p_align = \
                struct.unpack_from("<IIIIIIII", raw, off)
            if p_type == 1:
                segs.append((p_offset, p_vaddr, p_filesz, p_memsz, p_flags))
        self.segs = segs
        self.raw = raw
        flash = next(s for s in segs if s[1] == FLASH)
        self.vector = struct.unpack_from("<64I", raw, flash[0])[:16]

    def _map(self):
        self.uc.mem_map(FLASH, FLASH_SZ)
        self.uc.mem_map(SRAM, SRAM_SZ)
        self.uc.mem_map(PERIPH, PERIPH_SZ)
        self.uc.mem_map(SYSTEM, SYSTEM_SZ)
        self.uc.mem_map(0x42000000, 0x2000000)   # peripheral bit-band alias
        self.uc.mem_map(0x22000000, 0x2000000)   # SRAM bit-band alias
        flash_fsz = 0
        ram_off = ram_fsz = 0
        for off, vaddr, fsz, msz, fl in self.segs:
            if vaddr == FLASH:
                self.uc.mem_write(FLASH, self.raw[off:off + fsz])
                flash_fsz = fsz
            elif vaddr == SRAM:
                ram_off, ram_fsz = off, fsz
                self.uc.mem_write(SRAM, self.raw[off:off + fsz])
                if msz > fsz:
                    self.uc.mem_write(SRAM + fsz, b"\x00" * (msz - fsz))
        # `.data` is linked `>RAM AT> FLASH`: the startup copies its initial values
        # from the flash LMA (right after the flash content). The ELF stores those
        # bytes only in the RAM segment, so also place them at the flash LMA.
        if ram_fsz > 0:
            self.uc.mem_write(FLASH + flash_fsz, self.raw[ram_off:ram_off + ram_fsz])

    def reset(self):
        self.mmio[RCC + 0x00] = 0x1             # HSI on after reset
        self.mmio[SCB + 0x08] = 0x08000000      # VTOR = flash base (vector table)
        self.uc.reg_write(UC_ARM_REG_MSP, self.vector[0])
        self.uc.reg_write(UC_ARM_REG_SP, self.vector[0])
        self.uc.reg_write(UC_ARM_REG_PC, self.vector[1])

    def _hooks(self):
        self.uc.hook_add(UC_HOOK_MEM_READ | UC_HOOK_MEM_WRITE, self._periph_hook,
                         begin=PERIPH, end=PERIPH + PERIPH_SZ - 1)
        self.uc.hook_add(UC_HOOK_MEM_READ | UC_HOOK_MEM_WRITE, self._system_hook,
                         begin=SYSTEM, end=SYSTEM + SYSTEM_SZ - 1)
        self.uc.hook_add(UC_HOOK_MEM_READ | UC_HOOK_MEM_WRITE, self._bitband_hook,
                         begin=0x42000000, end=0x43FFFFFF)
        self.uc.hook_add(UC_HOOK_MEM_READ | UC_HOOK_MEM_WRITE, self._bitband_hook,
                         begin=0x22000000, end=0x23FFFFFF)

    def _periph_hook(self, uc, access, address, size, value, user_data):
        if access == UC_MEM_WRITE:
            self._periph_write(address, size, value)
        else:
            v = self._periph_read(address, size)
            uc.mem_write(address, v.to_bytes(size, "little"))
        return True

    def _system_hook(self, uc, access, address, size, value, user_data):
        if access == UC_MEM_WRITE:
            self._system_write(address, size, value)
        else:
            v = self._system_read(address, size)
            uc.mem_write(address, v.to_bytes(size, "little"))
        return True

    def _periph_read(self, addr, size):
        if addr == USART2:
            return self.uart_sr
        if USART2 <= addr < USART2 + 0x40:
            return self.mmio.get(addr, 0)
        if I2C1 <= addr < I2C1 + 0x40:
            return self.i2c1.read(addr - I2C1)
        if addr == RCC + 0x00:
            cr = self.mmio.get(addr, 0)
            if cr & (1 << 0):
                cr |= (1 << 1)                    # HSIRDY follows HSION
            if cr & (1 << 16):
                cr |= (1 << 17)                   # HSERDY follows HSEON
            if cr & (1 << 24):
                cr |= (1 << 25)                   # PLLRDY follows PLLON
            return cr
        if addr == RCC + 0x04:
            return self.mmio.get(addr, 0)
        if addr == FLASH_IF + 0x0C:
            return self.mmio.get(addr, 0) & ~1
        return self.mmio.get(addr, 0)

    def _periph_write(self, addr, size, value):
        if addr == USART2 + 0x04:
            self.uart_tx.append(value & 0xFF)
            return
        if USART2 <= addr < USART2 + 0x40:
            self.mmio[addr] = value
            return
        if I2C1 <= addr < I2C1 + 0x40:
            self.i2c1.write(addr - I2C1, value)
            return
        if addr == RCC + 0x04:
            value = (value & ~0xC) | ((value & 0x3) << 2)
        self.mmio[addr] = value

    def _system_read(self, addr, size):
        if addr == SYSTICK + 0x00:
            return self.systick["ctrl"]
        if addr == SYSTICK + 0x04:
            return self.systick["load"]
        if addr == SYSTICK + 0x08:
            return self.systick["val"]
        if addr == SCB + 0x04:
            v = 0
            if self.systick["pending"]:
                v |= (1 << 25)
            if self.pendsv_pending:
                v |= (1 << 28)
            return v
        return self.mmio.get(addr, 0)

    def _system_write(self, addr, size, value):
        if addr == SYSTICK + 0x00:
            self.systick["ctrl"] = value & 0x7
        elif addr == SYSTICK + 0x04:
            self.systick["load"] = value & 0xFFFFFF
        elif addr == SYSTICK + 0x08:
            self.systick["val"] = 0
        elif addr == SCB + 0x04:      # ICSR
            if value & (1 << 28):
                self.pendsv_pending = True
            if value & (1 << 27):
                self.pendsv_pending = False
        else:
            self.mmio[addr] = value

    def _bitband_target(self, addr):
        if 0x42000000 <= addr < 0x44000000:
            off = addr - 0x42000000
            base = 0x40000000
        elif 0x22000000 <= addr < 0x24000000:
            off = addr - 0x22000000
            base = 0x20000000
        else:
            return None, 0
        byte_off = off >> 5
        bit_in_byte = (off >> 2) & 7
        word_addr = base + (byte_off & ~3)
        abs_bit = (byte_off & 3) * 8 + bit_in_byte
        return word_addr, abs_bit

    def _bitband_read(self, addr):
        target, bit = self._bitband_target(addr)
        if target is None:
            return 0
        if target >= 0x40000000:
            word = self._periph_read(target, 4)
        else:
            word = int.from_bytes(self.uc.mem_read(target, 4), "little")
        return (word >> bit) & 1

    def _bitband_write(self, addr, value):
        target, bit = self._bitband_target(addr)
        if target is None:
            return
        if target >= 0x40000000:
            word = self._periph_read(target, 4)
            word = (word | (1 << bit)) if (value & 1) else (word & ~(1 << bit))
            self._periph_write(target, 4, word)
        else:
            word = int.from_bytes(self.uc.mem_read(target, 4), "little")
            word = (word | (1 << bit)) if (value & 1) else (word & ~(1 << bit))
            self.uc.mem_write(target, word.to_bytes(4, "little"))

    def _bitband_hook(self, uc, access, address, size, value, user_data):
        if access == UC_MEM_WRITE:
            self._bitband_write(address, value)
        else:
            v = self._bitband_read(address)
            uc.mem_write(address, v.to_bytes(size, "little"))
        return True

    def _fire_exception(self, n):
        uc = self.uc
        self._exc_depth += 1
        control = uc.reg_read(UC_ARM_REG_CONTROL)
        use_psp = bool(control & 0x2)      # Thread mode uses PSP
        sp = uc.reg_read(UC_ARM_REG_PSP) if use_psp else uc.reg_read(UC_ARM_REG_MSP)
        frame = struct.pack("<8I",
                            uc.reg_read(UC_ARM_REG_R0), uc.reg_read(UC_ARM_REG_R1),
                            uc.reg_read(UC_ARM_REG_R2), uc.reg_read(UC_ARM_REG_R3),
                            uc.reg_read(UC_ARM_REG_R12), uc.reg_read(UC_ARM_REG_LR),
                            uc.reg_read(UC_ARM_REG_PC), uc.reg_read(UC_ARM_REG_XPSR))
        sp -= 32
        uc.mem_write(sp, frame)
        if use_psp:
            uc.reg_write(UC_ARM_REG_PSP, sp)
        else:
            uc.reg_write(UC_ARM_REG_MSP, sp)
        # Enter handler mode: SPSEL=0 makes SP alias MSP automatically.
        uc.reg_write(UC_ARM_REG_CONTROL, control & ~0x2)
        # LR = EXC_RETURN (Thread mode, MSP or PSP).
        uc.reg_write(UC_ARM_REG_LR, 0xFFFFFFFD if use_psp else 0xFFFFFFF9)
        uc.reg_write(UC_ARM_REG_PC, self.vector[n] | 1)

    def _fire_systick(self):
        self._fire_exception(15)
        self.systick["pending"] = False
        self.systick["val"] = self.systick["load"]

    def _handle_exception(self, e):
        """Handle SVC instructions and EXC_RETURN branches Unicorn can't model."""
        cur = self.uc.reg_read(UC_ARM_REG_PC)
        addr = cur & ~1
        # SVC instruction (Unicorn advances PC past it before raising).
        try:
            insn = int.from_bytes(self.uc.mem_read(addr - 2, 2), "little")
        except UcError:
            insn = 0
        if (insn & 0xFF00) == 0xDF00:
            self.uc.reg_write(UC_ARM_REG_PC, addr | 1)
            self._fire_exception(11)      # SVC
            return True
        # EXC_RETURN value (handler did `bx r14` with a real EXC_RETURN).
        if 0xFFFFFFE0 <= addr <= 0xFFFFFFFE:
            self._do_exc_return(addr)
            return True
        return False

    def _do_exc_return(self, er):
        uc = self.uc
        use_psp = bool(er & 0x4)         # EXC_RETURN bit 2: 0=MSP, 1=PSP
        control = uc.reg_read(UC_ARM_REG_CONTROL)
        if use_psp:
            control |= 0x2               # Thread mode uses PSP
        else:
            control &= ~0x2
        uc.reg_write(UC_ARM_REG_CONTROL, control)
        sp = uc.reg_read(UC_ARM_REG_PSP) if use_psp else uc.reg_read(UC_ARM_REG_MSP)
        r0, r1, r2, r3, r12, lr, pc, xpsr = struct.unpack("<8I", uc.mem_read(sp, 32))
        uc.reg_write(UC_ARM_REG_R0, r0)
        uc.reg_write(UC_ARM_REG_R1, r1)
        uc.reg_write(UC_ARM_REG_R2, r2)
        uc.reg_write(UC_ARM_REG_R3, r3)
        uc.reg_write(UC_ARM_REG_R12, r12)
        uc.reg_write(UC_ARM_REG_LR, lr)
        sp += 32
        if use_psp:
            uc.reg_write(UC_ARM_REG_PSP, sp)
            uc.reg_write(UC_ARM_REG_CONTROL, control | 0x2)   # SP aliases PSP
        else:
            uc.reg_write(UC_ARM_REG_MSP, sp)
            uc.reg_write(UC_ARM_REG_CONTROL, control & ~0x2)  # SP aliases MSP
        uc.reg_write(UC_ARM_REG_PC, pc)
        uc.reg_write(UC_ARM_REG_XPSR, xpsr)
        self._exc_depth -= 1

    def run(self, max_insn=100_000_000, max_uart=65536, batch=10, cli=False):
        if cli:
            threading.Thread(target=self._cli_loop, daemon=True).start()
        self._running = True
        insn = 0
        tick_counter = 0
        while self._running and insn < max_insn and len(self.uart_tx) < max_uart:
            if self.pendsv_pending:
                self.pendsv_pending = False
                self._fire_exception(14)      # PendSV (FreeRTOS context switch)
            if self.systick["pending"] and (self.systick["ctrl"] & 1):
                self._fire_systick()
            pc = self.uc.reg_read(UC_ARM_REG_PC) | 1
            try:
                self.uc.emu_start(pc, 0, count=batch)
            except UcError as e:
                if self._handle_exception(e):
                    continue
                return bytes(self.uart_tx), f"fault {e} at PC=0x{pc:08X}"
            insn += batch
            if self.systick["ctrl"] & 1:
                load = self.systick["load"] or 7999
                tick_counter += batch
                while tick_counter >= load + 1:
                    tick_counter -= (load + 1)
                    self.systick["pending"] = True
        return bytes(self.uart_tx), f"stopped insn={insn}"

    # ---- CLI ----
    def handle_command(self, line):
        line = line.strip()
        if not line:
            return None
        parts = line.split()
        cmd = parts[0].lower()
        if cmd == "set" and len(parts) >= 4:
            dev = self.devices.get(parts[1].lower())
            if not dev:
                return f"unknown device '{parts[1]}'"
            key = parts[2]
            val = parts[3]
            try:
                if key in ("tag_uid", "uid"):
                    dev.set_param("tag_uid", " ".join(parts[3:]))
                elif key in ("tag_present", "present"):
                    dev.set_param("tag_present", val not in ("0", "false", "False"))
                elif key in ("temp", "temperature", "temp_c"):
                    dev.set_param("temp_c", float(val))
                elif key in ("rh", "humidity", "rh_pct"):
                    dev.set_param("rh_pct", float(val))
                elif key in ("roll", "roll_deg", "angle"):
                    dev.set_param("roll_deg", float(val))
                elif key in ("pitch", "pitch_deg"):
                    dev.set_param("pitch_deg", float(val))
                elif key in ("current", "current_a", "amps"):
                    dev.set_param("current_a", float(val))
                elif key in ("bus", "bus_v", "voltage"):
                    dev.set_param("bus_v", float(val))
                else:
                    dev.set_param(key, float(val))
            except (ValueError, TypeError) as e:
                return f"bad value: {e}"
            return f"set {dev.name}.{key} = {dev.get_params().get(key)}"
        if cmd == "get" and len(parts) >= 2:
            dev = self.devices.get(parts[1].lower())
            if not dev:
                return f"unknown device '{parts[1]}'"
            return f"{dev.name}: {dev.get_params()}"
        if cmd == "list":
            return ", ".join(f"{d.name}@0x{d.addr7:02X}" for d in self.devices.values())
        if cmd in ("help", "?"):
            return "set <dev> <param> <value> | get <dev> | list | quit"
        if cmd == "quit":
            self._running = False
            return "stopping"
        return f"unknown command '{cmd}'"

    def _cli_loop(self):
        for line in sys.stdin:
            out = self.handle_command(line)
            if out:
                print(out, flush=True)
            if not self._running:
                break


def _default_devices():
    return [PN532()]


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("elf", nargs="?", default="D:/wk/ds2agent/htu21d-f103/firmware.elf")
    ap.add_argument("--sht31", action="store_true")
    ap.add_argument("--htu21d", action="store_true")
    ap.add_argument("--pn532", action="store_true")
    args = ap.parse_args()
    devices = []
    if args.sht31:
        devices.append(SHT31())
    if args.htu21d:
        devices.append(HTU21D())
    if args.pn532 or not devices:
        devices.append(PN532())
    emu = F103(args.elf, devices=devices)
    print(f"attached: {', '.join(d.name for d in devices)}  (CLI: set/get/list/quit)", flush=True)
    out, status = emu.run(cli=True)
    print("\nSTATUS:", status)
    print("UART:", out.decode("ascii", "replace"))
