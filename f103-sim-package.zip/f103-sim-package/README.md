# F103 双后端仿真包

STM32F103 的两种仿真后端实现 + 器件 datasheet。

## 内容

| 目录/文件 | 说明 |
|---|---|
| `qemu-f103/` | QEMU 11.1.3 的 `nucleo-f103rb` 板子（C 源码 + 集成 patch） |
| `unicorn-f103/` | Unicorn F103 仿真器（Python）+ 5 个器件模型（SHT31/HTU21D/PN532/ADXL345/INA219） |
| `markdown/` | 10 个 datasheet 的 MinerU Markdown |
| `pdfs/` | 原始 datasheet PDF |
| `qa_table.txt` | QA 表 |
| `qemu_f103_usage.md` | QEMU 使用文档 |

## 两个后端

| 后端 | 形态 | 可调参数 | 已验证 |
|---|---|---|---|
| QEMU | C QOM，编译进 QEMU 11.1.3 | `-global sht31.temp_mc=30000` 等 | 三工程 boot + 读传感器 + 控制闭环 |
| Unicorn | Python（`f103_emu.py` + `devices.py`） | CLI `set/get/list` | 三工程 + PN532 + 控制闭环 |

QEMU 集成与运行见 `qemu-f103/README.md` 和 `qemu_f103_usage.md`。
